# Changelog 

## v0.13.0
### Changes
 - Added support for [EnchantedBookEnabler](https://www.curseforge.com/minecraft/data-packs/enchantedbookenabler) by [stefanj2_](https://www.curseforge.com/members/stefanj2_/projects)

## V0.12.0
### Changes
 - Projectile Protection now has 4 different textures 
 - Fire Protection now has 4 different textures
 - Protection now has 4 different textures